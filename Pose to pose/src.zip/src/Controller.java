
public interface Controller {
	public void loop();	
}
